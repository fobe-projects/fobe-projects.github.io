#define ATTR_PACKED     __attribute__((__packed__))
#define ATTR_ALIGNED(x) __attribute__((__aligned__(x)))
#define ATTR_SECTION(x) __attribute__((__section__(x)))
