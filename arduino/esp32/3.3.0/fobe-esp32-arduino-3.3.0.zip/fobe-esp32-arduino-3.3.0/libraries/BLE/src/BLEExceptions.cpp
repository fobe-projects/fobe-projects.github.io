/*
 * BLExceptions.cpp
 *
 *  Created on: Nov 27, 2017
 *      Author: kolban
 */

#include "soc/soc_caps.h"
#if SOC_BLE_SUPPORTED

//#include "BLEExceptions.h"

#endif /* SOC_BLE_SUPPORTED */
